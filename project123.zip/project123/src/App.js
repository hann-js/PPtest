import logo from './logo.svg';
import './App.css';
import Rating from './Component/Rating';

function App() {
  return (
    <div className="App" className="app-styling">
      <Rating />
    </div>
  );
}

export default App;
