import React, { useState } from 'react';
import Star from './Star';

const Rating = () => {
    const textMap = {
        1: 'Poor',
        2: 'Not satisfactory',
        3: 'Average',
        4: 'Good',
        5: 'Outstanding',
    }
    const clickHandler = (e, levelClicked) => {
        setLevelSelected(levelClicked)
    }
    const [levelSelected, setLevelSelected] = useState();

    return (<>
        <div style={{ display: 'flex', flexDirection: 'row' }}>
            <Star level={1} clickHandler={clickHandler} levelSelected={levelSelected} />
            <Star level={2} clickHandler={clickHandler} levelSelected={levelSelected} />
            <Star level={3} clickHandler={clickHandler} levelSelected={levelSelected} />
            <Star level={4} clickHandler={clickHandler} levelSelected={levelSelected} />
            <Star level={5} clickHandler={clickHandler} levelSelected={levelSelected} />
        </div>
        <div style={{ display: 'block' }}>{levelSelected && <p>{textMap[levelSelected]}</p>}</div>
    </>
    )
}

export default Rating;