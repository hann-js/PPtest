import React from 'react';
import '../App.css';

const Star = ({ level, clickHandler, levelSelected }) => {
    const getBackgroundColor = () => {
        if (level <= levelSelected) {
            return 'yellow'
        }
        return 'white'
    }
    return (
        <div className="star" style={{ backgroundColor: getBackgroundColor() }}
            onClick={(e) => { clickHandler(e, level) }}>{level}</div>
    )
}

export default Star;